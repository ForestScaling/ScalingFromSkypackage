## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message=FALSE, warning=FALSE---------------------------------------------
# library(sf)
library(dplyr)
library(ggplot2) # Added for plotting
library(purrr)
library(VGAM)
library(rstan)
library(posterior)
library(ScalingFromSkypackage)

# Load the sample data included with the package
data("harv_data_sample")

## -----------------------------------------------------------------------------
# Filter for a specific plot for a single-site example and extract the distribution of individual tree diameters
df_tile <- harv_data_sample %>%
  filter(IDhectbest == 1, !is.na(dbh)) %>%
  select(dbh)

## ----eval = FALSE-------------------------------------------------------------
# 
# # Load required packages
# library(itcSegment)
# 
# 
# # Suppose `segmentedtrees` is your shapefile of tree crowns
# # Make sure it has columns for height and geometry
# # Convert geometry to numeric metrics
# harvardshapefile$perimeter <- as.numeric(st_perimeter(harvardshapefile))
# harvardshapefile$area <- as.numeric(st_area(harvardshapefile))
# 
# # Estimate crown diameter from perimeter and area
# harvardshapefile <- harvardshapefile %>%
#   mutate(
#     Diameter = 0.5 * sqrt(perimeter^2 - (8 * area)),
#     # Calculate DBH using formula from Jucker et al. (2017)
#     # Be sure to set `biome` to your forest type (default is global, which is indicated by the integer 0, but the equation can change depending on your forest location. See dbh help file for integer numbers and which biome they indicate)
#     dbh = dbh(H = height, CA = Diameter, biome = 0)
#   )
# 
# # `dbh` now contains estimated diameters at breast height for each tree
# 
# 

## -----------------------------------------------------------------------------
kde_output <- potential_break(df_tile)

## ----results='asis'-----------------------------------------------------------
# The result of this function is a list containing the breakpoint and KDE data.
# We'll print a summary of the key output.
cat("### Estimated Breakpoint\n")
# The breakpoint is estimated on the log10 scale, so we exponentiate (10^x) 
# to convert back to the original DBH units (cm).
cat(10^kde_output$potential_breakpoint, "cm")

## -----------------------------------------------------------------------------
trunc_output <- truncate_filter(kde_output)

## ----message=FALSE, warning=FALSE---------------------------------------------
fit <- fit_alpha_model(
  bayesian_data = trunc_output$bayesian_data,
  breakpoint = trunc_output$final_breakpoint,
  LAI = 5.426,            # Example LAI value for the site
  prior_mean = 1.4,
  prior_sd = 0.3
)

## ----fig.height=4, fig.width=6, message=FALSE, warning=FALSE------------------
# Create a data frame for plotting the fitted line
plot_data <- tibble(
  dbh = seq(10, 50, length.out = 100),
  fit_n_dbh = dpareto(dbh, shape = fit$posterior_summary$mean, scale = 10)
)

# Plot the distribution and the fitted model
ggplot(trunc_output$bayesian_data, aes(x = dbh)) +
  geom_line(data = plot_data, aes(x = dbh, y = fit_n_dbh), color = "red", size = 1) +
  # scale_x_continuous(trans = 'log10') +
  # scale_y_continuous(trans = 'log10') +
  labs(title = "Estimated Size-Abundance (Density) Distribution",
       x = "Diameter at Breast Height (cm)",
       y = "Tree Density") +
  theme_bw()

## -----------------------------------------------------------------------------
trees <- estimate_total_trees(
  alpha_model_output = fit,
  N_tot_prior_mean = 1250,
  N_tot_prior_sd = 625
)

## ----fig.height=4, fig.width=6, message=FALSE, warning=FALSE------------------
# Create a data frame for plotting the fitted line
plot_data <- tibble(
  dbh = seq(10, 50, length.out = 100),
  fit_n_dbh = dpareto(dbh, shape = fit$posterior_summary$mean, scale = 10)* trees$posterior_summary$mean
)

# Plot the distribution and the fitted model
ggplot(trunc_output$bayesian_data, aes(x = dbh)) +
  geom_line(data = plot_data, aes(x = dbh, y = fit_n_dbh), color = "red", size = 1) +
  # scale_x_continuous(trans = 'log10') +
  # scale_y_continuous(trans = 'log10') +
  labs(title = "Estimated Size-Abundance Distribution",
       x = "Diameter at Breast Height (cm)",
       y = "Number of Trees") +
  theme_bw()

## -----------------------------------------------------------------------------
# Initialize empty lists to store results
alpha_results <- list()  # will store posterior summaries for alpha (power-law exponent) for each plot
tree_results <- list()   # will store posterior summaries for total number of trees (N_tot) for each plot

# Loop over each unique hectare plot in the sample dataset
for (i in unique(harv_data_sample$IDhectbest)) {
  
  # Subset the data for the current plot and remove rows with missing DBH
  df_tile <- harv_data_sample %>% 
    filter(IDhectbest == i, !is.na(dbh))
  
  # Skip plots with too few trees for meaningful analysis
  if (nrow(df_tile) < 25) next
  
  # Step 1: Identify potential breakpoint using KDE and bootstrapping
  # Wrap in tryCatch to skip plots where the function fails
  kde_output <- tryCatch(
    potential_break(df_tile), 
    error = function(e) NULL  # return NULL if an error occurs
  )
  if (is.null(kde_output)) next  # skip to next plot if KDE fails
  
  # Step 2: Refine breakpoint and determine upper truncation
  trunc_output <- tryCatch(
    truncate_filter(kde_output), 
    error = function(e) NULL
  )
  if (is.null(trunc_output)) next  # skip if truncation fails
  
  # Step 3: Fit Bayesian Pareto model to estimate alpha
  fit <- tryCatch(
    fit_alpha_model(
      bayesian_data = trunc_output$bayesian_data,        # filtered data within observation window
      breakpoint = trunc_output$final_breakpoint,       # refined lower bound
      LAI = 3.5,                                        # leaf area index for the site
      prior_mean = 1.4,                                 # prior mean for alpha
      prior_sd = 0.3                                    # prior SD for alpha
    ), 
    error = function(e) NULL
  )
  if (is.null(fit)) next  # skip if Bayesian model fails
  
  # Step 4: Estimate total number of trees (N_tot) using posterior samples of alpha
  trees <- tryCatch(
    estimate_total_trees(fit),
    error = function(e) NULL
  )
  if (is.null(trees)) next  # skip if total tree estimation fails
  
  # Store the results in the lists, using a unique plot identifier
  alpha_results[[paste0("HARV_", i)]] <- fit$posterior_summary  # posterior summary for alpha
  tree_results[[paste0("HARV_", i)]] <- trees$posterior_summary # posterior summary for N_tot
}


## ----eval = FALSE-------------------------------------------------------------
# # Load necessary packages for parallel processing
# library(foreach)      # provides foreach loops for parallel execution
# library(doParallel)   # allows registering parallel backends
# 
# # Detect the number of CPU cores available, and leave one core free for system processes
# n_cores <- parallel::detectCores() - 1
# cl <- makeCluster(n_cores)    # create a cluster object with the available cores
# registerDoParallel(cl)         # register the cluster for use with foreach
# 
# # Initialize lists to store results after the loop
# alpha_results <- list()  # posterior summaries for alpha (power-law exponent)
# tree_results <- list()   # posterior summaries for total number of trees (N_tot)
# 
# # Parallelized foreach loop
# # Each iteration runs in parallel on a different core
# alpha_tree_results <- foreach(
#   i = unique(harv_data_sample$IDhectbest),      # loop over unique hectare plot IDs
#   .packages = c("dplyr", "ScalingFromSkypackage")  # packages needed in each worker
# ) %dopar% {   # %dopar% tells foreach to execute in parallel instead of sequentially
# 
#   # Subset the data for the current plot and remove rows with missing DBH
#   df_tile <- harv_data_sample %>% filter(IDhectbest == i, !is.na(dbh))
# 
#   # Skip plots with too few trees
#   if (nrow(df_tile) < 25) return(NULL)
# 
#   # Step 1: Identify potential breakpoint using KDE and bootstrapping
#   kde_output <- tryCatch(
#     potential_break(df_tile),
#     error = function(e) NULL   # return NULL if the function fails
#   )
#   if (is.null(kde_output)) return(NULL)
# 
#   # Step 2: Refine breakpoint and determine upper truncation
#   trunc_output <- tryCatch(
#     truncate_filter(kde_output),
#     error = function(e) NULL
#   )
#   if (is.null(trunc_output)) return(NULL)
# 
#   # Step 3: Fit Bayesian Pareto model to estimate alpha
#   fit <- tryCatch(
#     fit_alpha_model(
#       trunc_output$bayesian_data,       # filtered data
#       trunc_output$final_breakpoint,    # refined lower breakpoint
#       LAI = 3.5,                        # leaf area index
#       prior_mean = 1.4,                 # prior mean for alpha
#       prior_sd = 0.3                     # prior SD for alpha
#     ),
#     error = function(e) NULL
#   )
#   if (is.null(fit)) return(NULL)
# 
#   # Step 4: Estimate total number of trees (N_tot) using posterior samples of alpha
#   trees <- tryCatch(
#     estimate_total_trees(fit),
#     error = function(e) NULL
#   )
#   if (is.null(trees)) return(NULL)
# 
#   # Return both alpha and tree results as a list
#   list(alpha = fit$posterior_summary, trees = trees$posterior_summary)
# }
# 
# # Combine results from parallel execution into named lists
# for (i in seq_along(alpha_tree_results)) {
#   if (!is.null(alpha_tree_results[[i]])) {
#     site_name <- paste0("HARV_", unique(harv_data_sample$IDhectbest)[i])
#     alpha_results[[site_name]] <- alpha_tree_results[[i]]$alpha
#     tree_results[[site_name]] <- alpha_tree_results[[i]]$trees
#   }
# }
# 
# # Stop the parallel cluster when finished to free system resources
# stopCluster(cl)
# 

