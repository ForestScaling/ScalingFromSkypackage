#' Harvard Forest Sample Dataset
#'
#' A sample dataset derived from the Harvard Forest CTFS-ForestGEO Mapped Forest Plot
#' (HF253) and supplemented with canopy height measurements from the NEON Airborne
#' Observation Platform (AOP). This dataset provides tree-level information used in
#' the \pkg{ScalingFromSky} package for examples and testing.
#'
#' The dataset contains a subset of the full Harvard Forest plot (see Source), including
#' bounding box coordinates, canopy structural attributes, and derived estimates of
#' diameter at breast height (DBH).
#'
#' @format A data frame with 5903 observations and 23 variables:
#' \describe{
#'   \item{xmin, ymin, xmax, ymax}{Bounding box coordinates for each tree crown (numeric).}
#'   \item{label}{Object classification label (character, e.g. "Tree").}
#'   \item{score}{Confidence score for the tree detection (numeric).}
#'   \item{image_path}{Path to the remote sensing image tile (character).}
#'   \item{left, right, top, bottom}{Image coordinates (numeric).}
#'   \item{Area, Perimeter}{Polygon area and perimeter of the crown segment (numeric).}
#'   \item{OBJECTID, Join_Count, TARGET_FID, Id}{Identifiers and join indices (numeric/integer).}
#'   \item{IDhectbest}{Hectare identifier (numeric).}
#'   \item{Shape_Leng, Shape_Area}{Shape geometry attributes (numeric).}
#'   \item{Max_Height}{Maximum canopy height from NEON AOP canopy height model (numeric, meters).}
#'   \item{Diameter}{Estimated canopy diameter (numeric, meters).}
#'   \item{dbh}{Estimated diameter at breast height (DBH, numeric, centimeters).}
#' }
#'
#' @details
#' Canopy height values (\code{Max_Height}) were extracted from the NEON Canopy Height
#' Model (CHM) using zonal statistics applied to Harvard Forest crown segments.
#'
#' Canopy diameter (\code{Diameter}) was derived from crown geometry following:
#' \deqn{Diameter = 0.5 \times \sqrt{Perimeter^2 - 8 \times Area}}
#'
#' Diameter at breast height (\code{dbh}) was estimated from canopy height and canopy
#' diameter using the allometric equation implemented in \pkg{itcSegment}:
#' \deqn{dbh = itcSegment::dbh(H = Max\_Height, CA = Diameter)}
#' 
#' IDhectbest is not in the original ForestGEO data, and is instead the result of a
#' fishnet shapefile with 1 hectare squares overlaid on top of the original plot.
#' The original plot is much larger than 1 hectare.
#'
#' This dataset is intended for demonstration and testing purposes within the
#' \pkg{ScalingFromSky} package. It includes only a subset of the original Harvard Forest
#' dataset and should not be used as a replacement for the full CTFS-ForestGEO plot data.
#'
#' @source
#' Harvard Forest CTFS-ForestGEO Mapped Forest Plot (HF253):
#' \url{https://harvardforest1.fas.harvard.edu/exist/apps/datasets/showData.html?id=hf253}
#' NEON Airborne Observation Platform (AOP): \url{https://www.neonscience.org/data-collection/airborne-remote-sensing}
#'
#' @examples
#' data(harv_data_sample)
#' # Quick look
#' head(harv_data_sample)
#'
#' # Relationship between canopy height and estimated DBH
#' plot(harv_data_sample$Max_Height, harv_data_sample$dbh,
#'      xlab = "Canopy Height (m)", ylab = "DBH (cm)",
#'      main = "Height vs DBH in Harvard Forest sample")
#'
"harv_data_sample"
